try:
   from pyodide.ffi import can_run_sync
except ImportError:
   from pyodide_js._module import validSuspender
   def can_run_sync():
      return bool(validSuspender.value)



from abc import ABC, abstractmethod
from pyodide.http import open_url, pyfetch
from pyodide.ffi import run_sync


class Transport(ABC):
    @abstractmethod
    def request(self, url, method="GET", data=None):
        """
        Make an HTTP request.
        """
        pass


class FetchTransport(Transport):
    def __init__(self):
        # Imported here to avoid issues 
        from pyodide.ffi import run_sync
        self.run_sync = run_sync

    async def async_http_request(self, url, method="GET", data=None):
        if method == "POST":
            response = await pyfetch(
                url,
                method="POST",
                body=data,
                headers={"Content-Type": "application/x-www-form-urlencoded"} if data else {},
            )
        else:
            response = await pyfetch(url, method="GET")

        return await response.text()

    def request(self, url, method="GET", data=None):
        return self.run_sync(self.async_http_request(url, method, data))


class OpenURLTransport(Transport):
    def request(self, url, method="GET", data=None):
        if method != "GET":
            raise ValueError("OpenURLTransport only supports GET requests.")
        return open_url(url).read()


def get_default_transport():
    try:
        if can_run_sync():     
            return FetchTransport()
    except Exception:
        pass
    return OpenURLTransport()